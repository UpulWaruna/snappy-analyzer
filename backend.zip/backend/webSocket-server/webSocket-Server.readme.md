.
├── api/
│   └── http/
│       └── handle/
│           └── socket_handler.go
├── application/
│   └── socket/
│       └── broadcast_uc.go
├── cmd/
│   └── main.go
├── domain/
│   └── model/
│       └── hub.go
└── go.mod