package middleware

import (
	"encoding/json"
	"fmt"
	"headlessBrowser-worker/domain/service"
	"net/http"
)

func CheckInCacheMiddleware(dataService *service.AnalysisDataService) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// 1. Get URL from request (assuming POST form or JSON)
			// Note: For HTMX, it's usually r.FormValue("url")
			targetURL := r.FormValue("url")
			if targetURL == "" {
				next.ServeHTTP(w, r)
				return
			}
			fmt.Println("from Cache middleware")

			// 2. Check Service/Repo
			cachedResult, err := dataService.RetrieveAnalysisResult(targetURL)
			fmt.Println("Cache lookup for URL:", targetURL, "Found:", cachedResult != nil)
			if err == nil && cachedResult != nil {
				// 3. CACHE HIT: Return the result directly!
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("X-Cache", "HIT") // Good for debugging

				// If using HTMX, you'd render the template here instead of JSON
				json.NewEncoder(w).Encode(map[string]interface{}{
					"status": "success",
					"data":   cachedResult,
					"source": "cache",
				})
				return // <--- STOP HERE: Don't call the next handler (Analysis)
			}

			// 4. CACHE MISS: Continue to the Analysis Handler
			w.Header().Set("X-Cache", "MISS")
			next.ServeHTTP(w, r)
		})
	}
}
